import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';

import { TechnologyListComponent } from './components/technology-list/technology-list.component';
import { TechnologyDetailsComponent } from './components/technology-details/technology-details.component';

@NgModule({
  declarations: [
    TechnologyListComponent,
    TechnologyDetailsComponent
  ],
  imports: [
    CommonModule
  ],
  exports:[
    TechnologyListComponent
  ]
})
export class TechnologyModule { }
