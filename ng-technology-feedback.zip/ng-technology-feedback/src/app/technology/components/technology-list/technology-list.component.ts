import { Component, OnInit } from '@angular/core';

import { Technology } from "../../models/technology";

import { TechnologyList } from "../../../mock-data";

@Component({
  selector: 'technology-list',
  templateUrl: './technology-list.component.html',
  styleUrls: ['./technology-list.component.css']
})
export class TechnologyListComponent implements OnInit {

  constructor() { }
  ngOnInit(): void {
  }
  public title: string = "Welcome To Technology List!";
  public subTitle: string = "Choose the correct technology to give a feedback!";
  public technologies: Technology[] = TechnologyList;
  
  public selectedTechnology: Technology;

  public onTechnologySelection(technology: Technology): void {
    this.selectedTechnology = technology;
  }
}
