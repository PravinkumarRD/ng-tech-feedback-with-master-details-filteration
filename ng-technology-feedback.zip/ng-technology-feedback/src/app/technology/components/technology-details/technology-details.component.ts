import { Component, OnInit, Input } from '@angular/core';

import { Technology } from "../../models/technology";

@Component({
  selector: 'technology-details',
  templateUrl: './technology-details.component.html',
  styleUrls: ['./technology-details.component.css']
})
export class TechnologyDetailsComponent implements OnInit {

  constructor() { }

  public title: string = "Details Of - ";
  @Input("technology") public technology:Technology;

  ngOnInit(): void {
  }

}
